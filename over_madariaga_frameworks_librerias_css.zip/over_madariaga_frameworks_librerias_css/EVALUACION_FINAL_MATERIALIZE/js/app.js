$(document).ready(function(){
	$('.sidenav').sidenav();
});

$('.enviar').click(function (argument) {
	alert('Comentario enviado con exito');
})